# -*- coding: utf-8 -*-

from bs4 import BeautifulSoup
import os
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
from urlparse import parse_qsl
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
path = addon.getAddonInfo('path')
cat_enabled = addon.getSetting('cat_enabled')
search_enabled = addon.getSetting('search_enabled')
other_context = addon.getSetting('other_context')
_url = sys.argv[0]
_handle = int(sys.argv[1])
apiurl = 'http://release24.pl/'
movies = 'filmy'
tv = 'seriale'
media = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
rel24ico = os.path.join(media, 'icon6.png')
rel24land = os.path.join(media, 'fanart3.jpg')
rel24next = os.path.join(media, 'next.png')
rel24back = os.path.join(media, 'back.png')
rel24search = os.path.join(media, 'search.png')


def notSupported(type):
    xbmcgui.Dialog().notification(addonname, type + ' nie obsługiwane', xbmcgui.NOTIFICATION_INFO);


def searchItems(query):
    dialog = xbmcgui.Dialog()
    search = dialog.input('Wpisz szukaną frazę', type=xbmcgui.INPUT_ALPHANUM, defaultt=query)
    getEntries(0, None, None, search)


def createLink(page, cat, subcat, search):
    url = apiurl
    if search is not None:
        url += 'szukacz/' + search + '//'
    if cat is not None:
        url += cat + '/'
    if subcat is not None:
        url += subcat + '/'
    url += str(page)
    # print('createLink: ' + url)
    return url


def appLinkAction(page, cat, subcat, search, action):
    url = _url + '?action=' + action + '&page=' + str(page)
    if cat is not None:
        url += '&cat=' + cat
    if subcat is not None:
        url += '&subcat=' + subcat
    if search is not None:
        url += '&search=' + search.replace(' ', '+')
    # print('appLink: ' + url)
    return url


def appLinkSearch(page, cat, subcat, search):
    return appLinkAction(page, cat, subcat, search, 'nextPage')


def appLink(page, cat, subcat):
    return appLinkAction(page, cat, subcat, None, 'nextPage')


def dftListItem(label):
    item = xbmcgui.ListItem(label=label)
    item.setArt({'thumb': rel24ico, 'fanart': rel24land})
    return item

def addMovieSubCat(listing):
    listing.append((appLink(0, movies, 'PL'), xbmcgui.ListItem(label='PL'), True))
    listing.append((appLink(0, movies, 'BDRIP'), xbmcgui.ListItem(label='BDRIP'), True))
    listing.append((appLink(0, movies, 'DVDRIP'), xbmcgui.ListItem(label='DVDRIP'), True))
    listing.append((appLink(0, movies, 'WEB-DL'), xbmcgui.ListItem(label='WEB-DL'), True))


def addTvSubCat(listing):
    listing.append((appLink(0, tv, 'Akcja'), xbmcgui.ListItem(label='Akcja'), True))
    listing.append((appLink(0, tv, 'Dramat'), xbmcgui.ListItem(label='Dramat'), True))
    listing.append((appLink(0, tv, 'Komedia'), xbmcgui.ListItem(label='Komedia'), True))
    listing.append((appLink(0, tv, 'Kryminał'), xbmcgui.ListItem(label='Kryminał'), True))
    listing.append((appLink(0, tv, 'Przygodowy'), xbmcgui.ListItem(label='Przygodowy'), True))
    listing.append((appLink(0, tv, 'Sci-Fi'), xbmcgui.ListItem(label='Sci-Fi'), True))
    listing.append((appLink(0, tv, 'Fantasy'), xbmcgui.ListItem(label='Fantasy'), True))
    listing.append((appLink(0, tv, 'Horror'), xbmcgui.ListItem(label='Horror'), True))
    listing.append((appLink(0, tv, 'Thriller'), xbmcgui.ListItem(label='Thriller'), True))
    listing.append((appLink(0, tv, 'Animowany'), xbmcgui.ListItem(label='Animowany'), True))
    listing.append((appLink(0, tv, 'Dokumentalny'), xbmcgui.ListItem(label='Dokumentalny'), True))


def addCategories(listing):
    listing.append((appLink(0, movies, None), dftListItem('Filmy >>'), True))
    listing.append((appLink(0, tv, None), dftListItem('Seriale >>'), True))


def addSearch(listing):
    if 'true' in search_enabled:
        searchButton = xbmcgui.ListItem(label='Szukaj')
        searchButton.setArt({'thumb': rel24search, 'fanart': rel24land})
        listing.append((appLinkAction(0, None, None, None, 'search'), searchButton, True))


def addCatSubcat(cat, subcat, listing, page, search):
    if 'true' in cat_enabled:
        if cat is None and subcat is None and page in '0' and search is None:
            addSearch(listing)
            addCategories(listing)
        elif cat is not None and subcat is None and page in '0':
            if movies in cat:
                addMovieSubCat(listing)
            elif tv in cat:
                addTvSubCat(listing)


def addBackButton(cat, subcat, listing, page):
    if page is not '0':
        backButton = xbmcgui.ListItem(label='Wróć do początku')
        backButton.setArt({'icon': rel24back, 'fanart': rel24land})  # , 'thumb': rel24ico
        if cat is None and subcat is None:
            listing.append((appLink(0, None, None), backButton, True))
        elif cat is not None and subcat is None:
            listing.append((appLink(0, None, None), backButton, True))
        elif cat is not None and subcat is not None:
            listing.append((appLink(0, cat, None), backButton, True))


def getSearchUrl(type, searchterm, target):
    url = 'plugin://plugin.video.' + target + '/?name="' + searchterm + '"&action='
    if 'seriale' in type:
        url += 'tvSearchterm'
    elif 'filmy' in type:
        url += 'movieSearchterm'
    else:
        url = appLinkAction(0, None, None, None, 'notSupported')
    return url


def videoInfo(name, descr, genre, director, writer, trailer):
    vinfoVideo = {}
    vinfoVideo['genre'] = genre
    vinfoVideo['director'] = director
    vinfoVideo['writer'] = writer
    vinfoVideo['title'] = name
    vinfoVideo['plot'] = descr
    vinfoVideo['originaltitle'] = name
    if trailer is not None:
        vinfoVideo['trailer'] = trailer
    return vinfoVideo


def videoArt(thumb):
    artVideo = {}
    artVideo['icon'] = thumb
    artVideo['thumb'] = thumb
    artVideo['poster'] = thumb
    artVideo['fanart'] = rel24land
    return artVideo


def checkTargetAddon(name):
    try:
        xbmcaddon.Addon(id=name)
    except RuntimeError:
        xbmcgui.Dialog().notification(addonname, 'Missing: ' + name, xbmcgui.NOTIFICATION_ERROR)
        addon.openSettings()


def getEntries(page, cat, subcat, search):
    # print('handle: ' + str(_handle) + ' ' + str(_url))
    checkTargetAddon('plugin.video.fanfilm')
    r = requests.get(createLink(page, cat, subcat, search))
    r.encoding = 'utf-8'
    data = r.text
    soup = BeautifulSoup(data, 'html.parser')
    entries = soup.findAll("div", {"class": "wpis"})
    pages = soup.find('div', {'id': 'pagin'}).findAll('p')
    listing = []
    nextPageNum = int(page) + 1
    addCatSubcat(cat, subcat, listing, str(page), search)
    for entry in entries:
        additional = entry.find('div', {'class': 'additionalicon'})
        add = None
        commands = []
        header = entry.find("h1")
        type = header.get('class')
        if type is not None:
            relName = header.find('a').get_text()
            thumbrow = entry.find("img", {"class": "posterimg"})
            info = entry.find("td", {"class": "info"})
            thumb = None
            name = None
            genre = None
            searchterm = None
            actors = []
            director = None
            writer = None
            trailer = None
            if thumbrow is not None:
                thumb = apiurl + thumbrow.get('src')
            if additional is not None:
                add = additional.find('img').get('alt')
            if info is not None:
                vidinfo = info.find("div", {"class": "row1 first"})
                infos = vidinfo.findAll("p", {"class": "i"})
                # itemInfo = ''
                for inf in infos:
                    infn = inf.find("span", {"class": "i"}).get_text()
                    infv = inf.find("span", {"class": "vi"}).get_text().replace(': ', '', 1).split('/')[0]
                    # itemInfo += '[B]' + infn.replace('.', '') + ': [/B]' + infv + '\n'
                    if 'Tytu' in infn:
                        searchterm = infv
                        name = '[B]' + infv + '[/B]'
                        if add is not None:
                            name += ' (' + add + ')'
                    elif 'Gatunek' in infn:
                        genre = infv
                    elif 'Aktorzy' in infn:
                        relActors = infv.split(',')
                        for act in relActors:
                            actors.append({'name': act})
                    elif 'yseria' in infn:
                        director = infv
                    elif 'Scenariusz' in infn:
                        writer = infv.split(',')

                descrrow = info.findAll("div", {"class": "row0"})
                # '[B]Opis:[/B]' +
                descr = descrrow[0].find("p").get_text().replace('OPIS:', '') + '\n'
                # descr += itemInfo
                vidurlOpt = descrrow[1].find("a", {"target": "_blank"})
                if vidurlOpt is not None:
                    # vidid = 'G8kNjHEAsN0' #  TEST_ID
                    # trailer = vidurlOpt.get('href')
                    vidid = vidurlOpt.get('href').replace('https://youtu.be/', '')
                    vidurl = 'RunPlugin(plugin://plugin.video.youtube/play/?video_id=' + vidid + ')'
                    trailer = 'plugin://plugin.video.youtube/play/?video_id=%s' % vidid
                    commands.append(('Trailer', vidurl))
            name += ' - ' + relName
            list_item = xbmcgui.ListItem(label=name)
            list_item.setCast(actors)
            list_item.setArt(videoArt(thumb))
            list_item.setInfo('video', videoInfo(name, descr, genre, director, writer, trailer))
            listing.append((getSearchUrl(type, searchterm, 'fanfilm'), list_item, True))
            commands.append(('Informacje', 'Action(Info)'))
            if 'true' in other_context:
                commands.append(('Incursion', 'RunPlugin(' + getSearchUrl(type, searchterm, 'incursion') + ')'))
            commands.append(('Wyszukaj podobne',
                             'Container.Refresh(' + appLinkAction(0, None, None, searchterm, 'search') + ')'))
            list_item.addContextMenuItems(commands)
    if len(pages) > 5:
        addBackButton(cat, subcat, listing, str(page))
        nextButton = xbmcgui.ListItem(label='[I]Następna strona[/I]')
        nextButton.setArt({'icon': rel24next, 'fanart': rel24land}) #  , 'thumb': rel24ico
        listing.append((appLinkSearch(nextPageNum, cat, subcat, search), nextButton, True))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action = 'nextPage'
    cat = None
    subcat = None
    page = 0
    search = None
    if params:
        if 'action' in params:
            action = params['action']
        if 'page' in params:
            print('PageIn: ' + str(params['page']))
            page = params['page']
        if 'cat' in params:
            cat = params['cat']
        if 'subcat' in params:
            subcat = params['subcat']
        if 'search' in params:
            search = params['search']
    if 'nextPage' in action:
        getEntries(page, cat, subcat, search)
    elif 'search' in action:
        searchItems(search)
    elif 'notSupported' in action:
        notSupported(cat)


if __name__ == '__main__':
    router(sys.argv[2][1:])

