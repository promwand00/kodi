# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcgui
import uuid

addon = xbmcaddon.Addon()
user = addon.getSetting('toya_go_user');
password = addon.getSetting('toya_go_pass');
sortType = addon.getSetting('toya_go_sort');
deviceid = addon.getSetting('toya_go_device')
token = addon.getSetting('toya_go_token')
firststart = addon.getSetting('toya_go_init')
addonname = addon.getAddonInfo('name')
server_enable = addon.getSetting('server_enable')
server_port = addon.getSetting('server_port')
epg = addon.getSetting('toya_go_epg')
m3u_dir = addon.getSetting('m3u_dir')
xmltv_dir = addon.getSetting('xmltv_dir')
toya_go_radio = addon.getSetting('toya_go_radio')
toya_go_camera = addon.getSetting('toya_go_camera')
server_radio = addon.getSetting('server_radio')
profile = dataPath = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
if deviceid == '':
    randomdev = str(uuid.uuid4().get_hex().upper()[0:10])
    addon.setSetting('toya_go_device', randomdev)
    deviceid = randomdev
if user == '' or password == '':
    addon.openSettings()
db = 'toyago'
monitor = xbmc.Monitor()
dialog = xbmcgui.Dialog()


def getSetting(name):
    return addon.getSetting(name)


def setSetting(name, value):
    addon.setSetting(name, value)


def openSettings():
    addon.openSettings()


def openIPTVsettings():
    xbmcaddon.Addon(id='pvr.iptvsimple').openSettings()
    # addon.openSettings('pvr.iptvsimple')


def setIptvSettings():
    iptvAddon = xbmcaddon.Addon(id='pvr.iptvsimple')
    iptvAddon.setSetting('epgUrl', 'https://raw.githubusercontent.com/toyago/epg/master/epg.xml')
    iptvAddon.setSetting('epgPathType', '1')
    location = profile
    if m3u_dir not in '':
        location = m3u_dir
    iptvAddon.setSetting('m3uPath', location + 'playlist.m3u8')
    iptvAddon.setSetting('m3uPathType', '0')
    # iptvAddon.openSettings()


def sendError(error):
    xbmcgui.Dialog().notification(addonname, error, xbmcgui.NOTIFICATION_ERROR)


def sendInfo(info):
    xbmcgui.Dialog().notification(addonname, info, xbmcgui.NOTIFICATION_INFO)


def logInfo(info):
    xbmc.log(msg=addonname + ' - ' + info, level=xbmc.LOGNOTICE)


def logError(error):
        xbmc.log(msg=addonname + ' - ' + error, level=xbmc.LOGERROR)

def runCreator():
    run = dialog.yesno(addonname, 'Chcesz skonfigurować dodatek?')
    if run == 1:
        confCreator()

def reauthCreator():
    again = dialog.yesno(addonname, 'Niepoprawy login lub hasło. Chcesz wprowadzić poprawne dane?')
    sendInfo(str(again))
    if again == 1:
        confCreator()

def confCreator():
    login = dialog.input('Podaj email (user@toya.net.pl)', defaultt=user, type=xbmcgui.INPUT_ALPHANUM)
    passw = dialog.input('Podaj hasło', type=xbmcgui.INPUT_ALPHANUM)
    import toyago
    API = toyago.GetInstance(deviceid, login, passw, '', False)
    try:
        API.authenticate(True)
        setSetting('toya_go_user', login)
        setSetting('toya_go_pass', passw)
        import kodiservice
        kodiservice.initdb(profile, db)
        kodiservice.updatechannels(deviceid, user, password, token, profile, db)
    except Exception as e:
        reauthCreator()
    confIptv = dialog.yesno(addonname, 'Chcesz skonfigurować automatycznie wtyczke IPTV? \nZostaniesz kilkakrotnie ' +
                                       'poproszony o restart. \nPotwierdż klikając OK')
    if confIptv == 1:
        try:
            # iptvsimple = xbmcaddon.Addon(id='pvr.iptvsimple')
            setIptvSettings()
        except RuntimeError as e:
            dialog.ok(addonname, 'Wygląda na to, że nie masz zainstalowanego dodatku IPTV Simple. Zinstaluj z ' +
                                 'Repozytorium (Klienty telewizji) i ponownie uruchom kreator w ustawieniach ToyaGO')


