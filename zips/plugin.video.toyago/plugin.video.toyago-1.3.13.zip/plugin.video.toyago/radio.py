# -*- coding: utf-8 -*-
import client
import model
from bs4 import BeautifulSoup

API_URL = 'https://go.toya.net.pl'
API_CAT = '/15'
CAT_URL = 'http://data.go.toya.net.pl/photo/categories/'

ITEM_CATEGORY = 'item isotope-item category'
ITEM_RADIO = 'item isotope-item category'


class GetInstance:

    def __init__(self):
        print()

    def getAllRadios(self):
        radios = []
        categories = self.getRadioCategories()
        for category in categories:
            catradios = self.getRadiosByCat(category.source)
            radios.extend(catradios)
        return radios

    def getRadiosByCat(self, catsource):
        soap = self.getSoap(API_URL + catsource)
        rads = soap.findAll("li", {"class": ITEM_RADIO})
        radios = []
        for rad in rads:
            source = rad.find("audio").get('src')
            img = rad.find("img").get('src')
            name = rad.find('span', {'class', 'item-small-title'}).getText().strip()
            radios.append(model.Radio(name, source, img))
        return radios

    def getRadioCategories(self):
        soap = self.getSoap(API_URL + API_CAT)
        cats = soap.findAll("li", {"class": ITEM_CATEGORY})
        categories = []
        for cat in cats:
            source = cat.find("a").get('href')
            img = cat.find("img").get('src')
            name = img.replace(CAT_URL, '').replace('.png', '').capitalize().replace('_', ' ')
            categories.append(model.Radio(name, source, img))
        return categories

    def getSoap(self, url):
        resp = client.requestJson(url)
        return BeautifulSoup(resp, 'html.parser')


if __name__ == '__main__':
    api = GetInstance()
    api.getAllRadios()

