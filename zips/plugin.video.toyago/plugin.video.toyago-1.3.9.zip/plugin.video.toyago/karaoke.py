import client
import model
import json
from bs4 import BeautifulSoup

API_URL = 'https://go.toya.net.pl'
API_CAT = '/23'
CAT_URL = 'http://data.go.toya.net.pl/photo/categories/'
ITEM_CATEGORY = 'item isotope-item category'
ITEM_KARAOKE = 'item isotope-item --locked search-item'


class GetInstance:

    def __init__(self):
        print()

    def getCamSource(self, camsource):
        soap = self.getSoap(API_URL + camsource)
        playerSrc = soap.find("div", {"class": 'main'}).find("a").get('data-stream')
        player = self.getSoap(API_URL + playerSrc)
        return player.find("div", {'id': 'player'}).get('data-stream')


    def getCamsByCat(self, catsource):
        soap = self.getSoap(API_URL + catsource)
        rads = soap.findAll("li", {"class": ITEM_KARAOKE})
        karas = []
        for rad in rads:
            source = rad.find("a").get('href')
            img = rad.find("img", {"class": "poster"}).get('src')
            name = rad.get('data-search')
            karas.append(model.Radio(name, source, img))
        return karas

    def getKaraokeCategories(self):
        soap = self.getSoap(API_URL + API_CAT)
        cats = soap.findAll("li", {"class": ITEM_CATEGORY})
        categories = []
        for cat in cats:
            source = cat.find("a").get('href')
            img = cat.find("img").get('src')
            name = img.replace(CAT_URL, '').replace('.png', '').capitalize().replace('_', ' ')
            categories.append(model.Radio(name, source, img))
        return categories

    def getSoap(self, url):
        resp = client.requestJson(url)
        return BeautifulSoup(resp, 'html.parser')


