# -*- coding: utf-8 -*-

import sys
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin
import xbmc
import toyago
import service
import time
import kodiservice
import control
import radio
import cameras

IMG_URL = 'http://data.go.toya.net.pl/logo/iconxmb'
IMG_RADIO = '/internetradio_icon_big.png'
IMG_CAMERA = '/camera_active.png'
IMG_TV = '/tv_icon_big.png'

# addon = xbmcaddon.Addon()
_url = sys.argv[0]
_handle = int(sys.argv[1])


def getRadios(source):
    reload(control)
    radapi = radio.GetInstance()
    radios = radapi.getRadiosByCat(source)
    listing = []
    for rad in radios:
        list_item = xbmcgui.ListItem(label=rad.name, thumbnailImage=rad.thumbnail)
        list_item.setProperty('fanart_image', rad.thumbnail)
        list_item.setArt({'landscape': rad.thumbnail})
        list_item.setProperty('IsPlayable', 'true')
        list_item.setInfo('music', {'title': rad.name})
        url = rad.source
        is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    if control.sortType == "1":
        xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.endOfDirectory(_handle, cacheToDisc=False)


def playCam(source):
    camapi = cameras.GetInstance()
    url = camapi.getCamSource(source).split('?')[0]
    play_item = xbmcgui.ListItem(path=url)
    # play_item.setInfo('video', {'title': 'A', 'genre': 'B', 'plot': 'C','plotoutline ': 'D', 'originaltitle': 'E'})
    # xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    xbmc.Player().play(url, play_item)


def getCams(source):
    reload(control)
    camapi = cameras.GetInstance()
    cams = camapi.getCamsByCat(source)
    listing = []
    for cam in cams:
        list_item = xbmcgui.ListItem(label=cam.name, thumbnailImage=cam.thumbnail)
        list_item.setProperty('fanart_image', cam.thumbnail)
        list_item.setArt({'landscape': cam.thumbnail})
        list_item.setProperty('IsPlayable', 'true')
        list_item.setInfo('music', {'title': cam.name})
        url = '{0}?action=playCam&source={1}'.format(_url, cam.source)
        is_folder = False
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    if control.sortType == "1":
        xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.endOfDirectory(_handle, cacheToDisc=False)


def getRadioCats(type):
    reload(control)
    api = None
    src = None
    if type is 'radio':
        api = radio.GetInstance()
        cats = api.getRadioCategories()
        src = 'radios'
    elif type is 'cam':
        api = cameras.GetInstance()
        cats = api.getCameraCategories()
        src = 'cams'
    listing = []
    for cat in cats:
        list_item = xbmcgui.ListItem(label=cat.name, thumbnailImage=cat.thumbnail)
        list_item.setProperty('fanart_image', cat.thumbnail)
        list_item.setArt({'landscape': cat.thumbnail})
        list_item.setProperty('IsPlayable', 'false')
        url = '{0}?action={1}&source={2}'.format(_url, src, cat.source)
        is_folder = True
        listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    if control.sortType == "1":
        xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.endOfDirectory(_handle, cacheToDisc=False)


def getChannels():
    reload(control)
    cids = []
    # channels = API.channels(cids)
    channels = kodiservice.getchannels(control.profile, True, control.db)
    epg = {}
    # epgmap = kodiservice.getcurrentepg(control.profile, control.db)
    if 'true' in control.epg:
        # print(str(control.epg))
        for ch in channels:
            cids.append(ch.cid)
        try:
            API = toyago.GetInstance(control.deviceid, control.user, control.password, control.token, True)
            API.epg(cids, epg)
        except Exception as e:
            control.reauthCreator()
            # control.sendError(str(e))

    listing = []
    addOptionalServices(listing, control)
    for channel in channels:
        if channel.source is not None:
            channelThumb = channel.thumbnail
            # title = '[COLOR green]' + channel.name + '[/COLOR]'
            title = '[B]' + channel.name + '[/B]'
            descr = ''
            epgTitle = ''
            next_title = ''
            # if str(channel.id) in epgmap:
            if str(channel.cid) in epg:
                # epgObj = epgmap[str(channel.id)]
                epgObj = epg[str(channel.cid)]
                if epgObj is not None:
                    title += '[I]' + ' - " ' + epgObj.title + ' "' + '[/I]'
                    descr = epgObj.descr
                    epgTitle = epgObj.title
                    next_title = ''
                    if epgObj.next_title is not None:
                        next_title = 'Nastepnie: ' + '[B]' + epgObj.next_title + '[/B]\n'
                    next_title += 'Teraz: ' + '[B]' + epgObj.title + '[/B]'
            list_item = xbmcgui.ListItem(label=title, thumbnailImage=channelThumb)
            list_item.setProperty('fanart_image', channelThumb)
            list_item.setInfo('video', {'title': title, 'genre': channel.genre, 'plot': next_title + '\n' + descr,
                                        'plotoutline ': epgTitle, 'originaltitle': epgTitle})
            list_item.setArt({'landscape': channelThumb})
            list_item.setProperty('IsPlayable', 'true')
            # url = '{0}?action=play&video={1}'.format(_url, channel.source)
            url = '{0}?action=play&video={1}'.format(_url, channel.id)
            is_folder = False
            listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    if control.sortType == "1":
        xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.endOfDirectory(_handle, cacheToDisc=False)


def addOptionalServices(listing, control):
    if control.toya_go_radio == 'true':
        list_item = xbmcgui.ListItem(label='Radio >>', thumbnailImage=IMG_URL + IMG_RADIO)
        is_folder = True
        url = '{0}?action=radioCats'.format(_url)
        listing.append((url, list_item, is_folder))
    if control.toya_go_camera == 'true':
        list_item = xbmcgui.ListItem(label='Kamery >>', thumbnailImage=IMG_URL + IMG_CAMERA)
        is_folder = True
        url = '{0}?action=camCats'.format(_url)
        listing.append((url, list_item, is_folder))


def play_video(path):
    ch = kodiservice.getchannel(control.profile, path, control.db)
    play_item = xbmcgui.ListItem(path=ch.source)
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'listing':
            print('listing')
        elif params['action'] == 'play':
            play_video(params['video'])
        elif params['action'] == 'stopServer':
            stopServer()
        elif params['action'] == 'startServer':
            startServer()
        elif params['action'] == 'iptvSettings':
            control.openIPTVsettings()
        elif params['action'] == 'setIptvSettings':
            control.setIptvSettings()
        elif params['action'] == 'refreshtoken':
            kodiservice.refreshsession()
        elif params['action'] == 'cleardb':
            kodiservice.cleardb()
        elif params['action'] == 'radioCats':
            getRadioCats('radio')
        elif params['action'] == 'radios':
            getRadios(params['source'])
        elif params['action'] == 'camCats':
            getRadioCats('cam')
        elif params['action'] == 'cams':
            getCams(params['source'])
        elif params['action'] == 'playCam':
            playCam(params['source'])
    else:
        getChannels()


def startServer():
    port = control.addon.getSetting('server_port');
    if service.serverOnline():
        xbmcgui.Dialog().notification(control.addonname, 'Server already started. Port: ' + str(port),
                                      xbmcgui.NOTIFICATION_INFO);
    else:
        service.startServer();
        time.sleep(5);
        if service.serverOnline():
            xbmcgui.Dialog().notification(control.addonname, 'Server started. Port: ' + str(port), xbmcgui.NOTIFICATION_INFO);
        else:
            xbmcgui.Dialog().notification(control.addonname, 'Server not started. Wait one moment and try again. ', xbmcgui.NOTIFICATION_ERROR);


def stopServer():
    if service.serverOnline():
        service.stopServer()
        time.sleep(5);
        xbmcgui.Dialog().notification(control.addonname, 'Server stopped.', xbmcgui.NOTIFICATION_INFO);
    else:
        xbmcgui.Dialog().notification(control.addonname, 'Server is already stopped.', xbmcgui.NOTIFICATION_INFO);


if __name__ == '__main__':
    router(sys.argv[2][1:])
