# -*- coding: utf-8 -*-

import client
import model
import json
from bs4 import BeautifulSoup

API_URL = 'https://go.toya.net.pl'
WEATHER = '/weather'
API_CAT = '/25'
ITEM_CATEGORY = 'item isotope-item category'
ITEM_CAMERA = 'item isotope-item --locked search-item'


class GetInstance:

    def __init__(self):
        print()

    def getCamSource(self, camsource):
        soap = self.getSoap(API_URL + camsource)
        # detailId = camsource.split('/')[2]
        # detailJson = client.requestJson(API_URL + WEATHER + '/' + detailId)
        # detailData = json.loads(detailJson)
        # print('WEATHER: ' + str(detailData['wind']))
        return soap.find("div", {"id": 'player'}).get('data-stream')

    def getCamsByCat(self, catsource):
        soap = self.getSoap(API_URL + catsource)
        rads = soap.findAll("li", {"class": ITEM_CAMERA})
        radios = []
        for rad in rads:
            source = rad.find("a").get('href')
            img = rad.find("img").get('src')
            name = rad.get('data-search')
            radios.append(model.Radio(name, source, img))
        return radios

    def getCameraCategories(self):
        soap = self.getSoap(API_URL + API_CAT)
        cats = soap.findAll("li", {"class": ITEM_CATEGORY})
        categories = []
        count = 0;
        for cat in cats:
            source = cat.find("a").get('href')
            img = cat.find("img").get('src')
            count += 1
            name = 'Pokaż kamery >>'
            categories.append(model.Radio(name, source, img))
        return categories

    def getSoap(self, url):
        resp = client.requestJson(url)
        return BeautifulSoup(resp, 'html.parser')
