# -*- coding: utf-8 -*-
# Module: NetflixHttpRequestHandler
# Author: asciidisco
# Created on: 11.10.2017
# License: MIT https://goo.gl/5bMj3H

"""Tests for the `NetflixHttpRequestHandler` module"""

import unittest
import mock
from resources.lib.NetflixHttpRequestHandler import NetflixHttpRequestHandler

class NetflixHttpRequestHandlerTestCase(unittest.TestCase):
    pass
